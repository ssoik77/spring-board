package com.peisia.service;

import java.util.ArrayList;

import org.springframework.ui.Model;

import com.peisia.dto.GuestDto;
import com.peisia.dto.GuestRegisterDto;


public interface GuestService {
	public ArrayList<GuestDto> getList(int startIndex);
	public ArrayList<GuestDto> getSerchList(int startIndex, String serchWord);
	public Model allListPage(Model m, int requestPage, String serchWord);
	
	
	public GuestDto read(long bno);
	public void del(long bno);
	public void write(GuestDto dto);
	public void modify(GuestDto dto);
	
	public boolean checkRegister(GuestRegisterDto registerDto, String checkRegisterPassword);
	public void register(GuestRegisterDto registerDto);
	
	public boolean login(GuestRegisterDto registerDto);
}
