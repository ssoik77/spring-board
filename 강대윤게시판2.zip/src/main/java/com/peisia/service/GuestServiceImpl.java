package com.peisia.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.peisia.dto.GuestDto;
import com.peisia.dto.GuestInputDto;
import com.peisia.dto.GuestRegisterDto;
import com.peisia.mapper.GuestMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class GuestServiceImpl implements GuestService {

	@Setter(onMethod_ = @Autowired)
	private GuestMapper mapper;

	@Override
	public ArrayList<GuestDto> getList(int startIndex) {
		log.info("비지니스 계층===========");

		startIndex = (startIndex - 1) * 5;
		return mapper.getList(startIndex);

	}

	@Override
	public ArrayList<GuestDto> getSerchList(int startIndex, String serchWord) {
		int limitIndex;

		limitIndex = (startIndex - 1) * 5;

		GuestInputDto inputDto = new GuestInputDto();

		inputDto.setLimitIndex(limitIndex);
		inputDto.setSerchWord(serchWord);

		return mapper.getSerchList(inputDto);

	}

	@Override
	public Model allListPage(Model m, int startIndex, String serchWord) {

		int listLimit = 5;
		int blockLimit = 3;
		int count = 0;

		if (serchWord == null) {
			count = mapper.allList().getCount();
		} else {
			count = mapper.allSerchList(serchWord).getCount();
		}

		int allPage = (int) Math.ceil((double) count / listLimit);

		int allBlock = (int) Math.ceil((double) allPage / blockLimit);

		int curruntBlockNo = (int) Math.ceil((double) startIndex / blockLimit);

		int endBlockPage = curruntBlockNo * 3;

		int startBlockPage = endBlockPage - 2;

		if (allPage < endBlockPage) {
			endBlockPage = allPage;
		}

		boolean hasPrev = true;
		boolean hasNext = true;

		if (startBlockPage == 1) {
			hasPrev = false;
		}

		if (endBlockPage == allPage) {
			hasNext = false;
		}

		m.addAttribute("allPage", allPage);
		m.addAttribute("allBlock", allBlock);
		m.addAttribute("curruntBlockNo", curruntBlockNo);
		m.addAttribute("endBlockPage", endBlockPage);
		m.addAttribute("startBlockPage", startBlockPage);
		m.addAttribute("hasPrev", hasPrev);
		m.addAttribute("hasNext", hasNext);
		m.addAttribute("serchWord", serchWord);

		return m;
	};

	@Override
	public GuestDto read(long bno) {
		return mapper.read(bno);
	}

	@Override
	public void del(long bno) {
		mapper.del(bno);
	}

	@Override
	public void write(GuestDto dto) {
		log.info("bno 테스트" + dto.getBno());
		mapper.write(dto);
	}

	@Override
	public void modify(GuestDto dto) {
		mapper.modify(dto);
	}

	@Override
	public boolean checkRegister(GuestRegisterDto registerDto, String checkRegisterPassword) {

		String id = registerDto.getId();
		String password = registerDto.getPw();
		String checkPassword = checkRegisterPassword;
		boolean hasAccount = true;

		ArrayList<GuestRegisterDto> registerList = mapper.registerList();
		if (registerList.size() > 0) {
			for (GuestRegisterDto list : registerList) {
				if (list.getId().equals(id)) {
					hasAccount = false;
					return hasAccount;
				}
			}
		}

		if (!password.equals(checkPassword)) {
			hasAccount = false;
			return hasAccount;
		}

		return hasAccount;

	}

	@Override
	public void register(GuestRegisterDto registerDto) {
		mapper.register(registerDto);
	}

	public boolean login(GuestRegisterDto registerDto) {
		boolean hasNext = false;

		ArrayList<GuestRegisterDto> memberList = mapper.registerList();

		for (GuestRegisterDto i : memberList) {
			if (i.getId().equals(registerDto.getId())) {
				if (i.getPw().equals(registerDto.getPw())) {
					hasNext = true;
					return hasNext;

				}
			}
		}
		return hasNext;
	}

}
