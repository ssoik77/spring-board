package com.peisia.dto;

import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class GuestRegisterDto {
	
	private String id;
	private String pw;
	
}
