package com.peisia.dto;

import lombok.Data;

@Data
public class GuestCountDto {

	private int count;
	
}
