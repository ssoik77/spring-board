package com.peisia.dto;

import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class GuestInputDto {

	private int limitIndex;
	private String serchWord;
	
}
