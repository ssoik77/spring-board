package com.peisia.mapper;

import java.util.ArrayList;

import com.peisia.dto.GuestCountDto;
import com.peisia.dto.GuestDto;
import com.peisia.dto.GuestInputDto;
import com.peisia.dto.GuestRegisterDto;

public interface GuestMapper {
	public ArrayList<GuestDto> getList(int limitIndex);
	public ArrayList<GuestDto> getSerchList(GuestInputDto inputDto);
	public GuestCountDto allList();
	public GuestCountDto allSerchList(String serchWord);
	public GuestDto read(long bno);
	public void del(long bno);
	public void write(GuestDto dto);
	public void modify(GuestDto dto);

	public ArrayList<GuestRegisterDto> registerList();
	public void register(GuestRegisterDto registerDto);
	
}
