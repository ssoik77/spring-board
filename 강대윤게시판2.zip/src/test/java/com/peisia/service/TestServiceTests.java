package com.peisia.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class TestServiceTests {
	
	
	@Setter(onMethod_= @Autowired)
	private TestService service;
	
	
	@Test
	public void testService() {
		int s1 = Integer.parseInt(service.getOne());
		int s2 = Integer.parseInt(service.getTwo());
		int s3 = s1+s2;
		log.info(s3);
	}

}
