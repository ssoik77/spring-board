package com.peisia.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.dto.GuestDto;
import com.peisia.service.GuestService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

//@Service
@RequestMapping("/guest/*")
@AllArgsConstructor
@Controller
@Log4j
public class GuestController {

	
	
	private GuestService guestService;
	
	@GetMapping("/getList")
	public void getList(Model model) {
		model.addAttribute("getList",guestService.guestList());
	}
	
	@GetMapping({"/read", "/edit"})
	public void readOrEdit(@RequestParam("bno") int bno,Model model) {
		log.info("컨트롤러 ==== 글번호 ==============="+bno);
	model.addAttribute("readOrEdit", guestService.read(bno));
	}
	
	@GetMapping("/del")
	public String del(@RequestParam("bno") int bno) {
		log.info("컨트롤러 ==== 삭제 글번호 ==============="+bno);
		guestService.del(bno);
		return "redirect:/";
	}
	
	@GetMapping("/write")
	public String writeTravel() {
	
	return "guest/write";	
		
	}
	
	@PostMapping("/write")
	public String write(GuestDto dto) {
		log.info("컨트롤러 ==== 글번호 ===============");
	guestService.write(dto);
	return "redirect:/";	
	}
	
	@PostMapping("/edit")
	public String edit(GuestDto dto) {
		log.info("컨트롤러 ==== 글번호 ==============="+dto.getBno());
		guestService.edit(dto);
		return "redirect:/";	
	}
	
	
	
	
	
}
