package com.peisia.mapper;

import java.util.ArrayList;

import com.peisia.dto.GuestDto;

public interface GuestMapper {
	
	public ArrayList<GuestDto> guestList();
	public GuestDto read(int bno);
	public void del(int bno);
	public void write(GuestDto dto);
	public void edit(GuestDto dto);

}
