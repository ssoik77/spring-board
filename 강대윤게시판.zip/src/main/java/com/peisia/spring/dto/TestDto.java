package com.peisia.spring.dto;

import lombok.Data;

@Data
public class TestDto {
	private int no;
	private String str_data;
	
}
