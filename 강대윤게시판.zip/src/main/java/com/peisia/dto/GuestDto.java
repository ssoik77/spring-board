package com.peisia.dto;

import lombok.Data;

@Data
public class GuestDto {

	private int bno;
	private String btext;
	
}
