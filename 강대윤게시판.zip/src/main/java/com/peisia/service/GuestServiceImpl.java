package com.peisia.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.peisia.dto.GuestDto;
import com.peisia.mapper.GuestMapper;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
public class GuestServiceImpl implements GuestService{

	private GuestMapper guestMapper;
	
	@Override
	public ArrayList<GuestDto> guestList(){
		return guestMapper.guestList();
	}
	@Override
	public GuestDto read(int bno) {
		return guestMapper.read(bno);
	}
	@Override
	public void del(int bno) {
		guestMapper.del(bno);
	}
	@Override
	public void write(GuestDto dto) {
		guestMapper.write(dto);
	}
	@Override
	public void edit(GuestDto dto) {
		guestMapper.edit(dto);
	}
	
	
}
